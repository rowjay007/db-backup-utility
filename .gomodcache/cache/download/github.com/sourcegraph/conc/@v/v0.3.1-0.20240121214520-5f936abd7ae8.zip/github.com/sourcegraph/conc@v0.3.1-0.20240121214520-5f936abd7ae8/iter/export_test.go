package iter

var DefaultMaxGoroutines = defaultMaxGoroutines
