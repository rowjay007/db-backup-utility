//go:build viper_bind_struct

package features

const BindStruct = true
